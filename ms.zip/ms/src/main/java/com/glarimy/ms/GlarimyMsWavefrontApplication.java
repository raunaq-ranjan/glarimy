package com.glarimy.ms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GlarimyMsWavefrontApplication {

	public static void main(String[] args) {
		SpringApplication.run(GlarimyMsWavefrontApplication.class, args);
	}

}
